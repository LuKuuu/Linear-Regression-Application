# Linear-Regression-Application
a web application with normal equation to help people make prediction
